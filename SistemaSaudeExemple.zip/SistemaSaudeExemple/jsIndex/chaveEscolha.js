document.getElementById('unidadeSaudePretendida_CP').addEventListener('change', function() {
    var selecionado = this.value;
    var redesDiv = document.querySelector('#unidadeSaudePretendida_CP-quaisRedes').parentElement;
    var unidadesDiv = document.querySelector('#unidadeSaudePretendida_CP-quaisUnidades').parentElement;

    if (selecionado === 'Sim') {
        redesDiv.style.display = 'block';
        unidadesDiv.style.display = 'block';
    } else {
        redesDiv.style.display = 'none';
        unidadesDiv.style.display = 'none';
    }
});
