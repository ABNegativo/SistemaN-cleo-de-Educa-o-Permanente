function aplicarMascaraData(input) {
    input.addEventListener('input', function () {
        let valor = input.value.replace(/\D/g, ''); 
        if (valor.length > 8) {
            valor = valor.substring(0, 8); 
        }
        if (valor.length >= 5) {
            input.value = valor.replace(/(\d{2})(\d{2})(\d{4})/, '$1/$2/$3');
        } else if (valor.length >= 3) {
            input.value = valor.replace(/(\d{2})(\d{2})/, '$1/$2');
        } else if (valor.length >= 1) {
            input.value = valor.replace(/(\d{2})/, '$1');
        }
    });
}

function aplicarMascaraTelefone(input) {
    input.addEventListener('input', function () {
        let valor = input.value.replace(/\D/g, ''); 
        if (valor.length > 11) {
            valor = valor.substring(0, 11); 
        }
        if (valor.length >= 7) {
            input.value = valor.replace(/(\d{2})(\d{4})(\d{4})/, '($1)$2-$3');
        } else if (valor.length >= 3) {
            input.value = valor.replace(/(\d{2})(\d{4})/, '($1)$2');
        } else if (valor.length >= 1) {
            input.value = valor.replace(/(\d{2})/, '($1');
        }
    });
}


aplicarMascaraData(document.getElementById('dateMascaraUm'));
aplicarMascaraData(document.getElementById('dateMascaraDois'));
aplicarMascaraData(document.getElementById('dateMascaraTres'));

aplicarMascaraTelefone(document.getElementById('celularMascaraUm'));
aplicarMascaraTelefone(document.getElementById('celularMascaraDois'));
